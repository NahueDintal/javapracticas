package com.cerrajeria.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CerrajeriaWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
